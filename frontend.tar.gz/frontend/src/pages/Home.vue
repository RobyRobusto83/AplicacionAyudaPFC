<template>
  <div class="starter-template">
    <h1>Título del proyecto</h1>
    <p class="lead">No has definido un PFC</p>          
    <a href="#/pfc" class="btn btn-primary btn-lg" role="button" aria-disabled="true">Defínelo</a>
  </div>
</template>

<script>
export default {
  name: 'App',
  components: {
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.starter-template {
  padding: 3rem 1.5rem;
  text-align: center;
}

</style>

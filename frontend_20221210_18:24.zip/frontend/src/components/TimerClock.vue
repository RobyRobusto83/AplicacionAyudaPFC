<template>
    <div id="app">
      <!-- <img class="img" src="@/assets/cronometro.png" /> -->
      <a class="timer">{{zfill(hour)}}:{{zfill(min)}}:{{zfill(sec)}}</a>
  
      <div class="btns">
        <button class="btn btn-timer" @click="play">{{timer !== null ? "Pausa" :"Empezar" }}</button>
        <button class="btn btn-timer" @click="clear">Reiniciar</button>
      </div>
  
      <div class="interval" v-show="intervalList.length > 0">
        <ul>
          <li v-for="interval in intervalList" :key="interval" >Pausa en {{interval}}</li>
        </ul>
        <button class="btn btn-timer" @click="clearIntervalList">Borrar</button>
      </div>
  
    </div>
  </template>
  
  <script>
  export default {
    name: 'TimerClock',
    data(){
      return{
        sec: 0,
        min: 0,
        hour: 0,
        timer: null,
        intervalList: []
      }
    },
    methods: {
      zfill(number){
        return number.toString().padStart(2,0)
      },
      play(){
        
        if(this.timer === null){
          this.playing()
          this.timer = setInterval(()=> this.playing(), 1000)
        }
        else{
          clearInterval(this.timer);
          this.timer = null;
          this.pause();
        }
      },
      playing(){
        this.sec++
        if(this.sec >= 59){
          this.sec = 0;
          this.min++;
        }
        if(this.min >= 59){
          this.min = 0;
          this.hour++;
        }
      },
      pause(){
        this.intervalList.push(`${this.zfill(this.hour)}:${this.zfill(this.min)}:${this.zfill(this.sec)}`)
        console.log(this.intervalList)
      },
      clear(){
        if(this.timer !== null){
          clearInterval(this.timer)
          this.timer = null
        }
        this.sec = 0;
        this.min = 0;
        this.hour = 0;
        this.clearIntervalList();
      },
      clearIntervalList(){
        this.intervalList = []
        console.log(this.intervalList)
      }
    }
  }
  </script>
  
  <style>
  .btns{
    margin-top: 10px;
    display: flex;
  }
 .btn-timer{
    -webkit-user-select: none;
    -moz-user-select: none;
    width: 150px;
    font-size: 20px;
    border: none;
    border-radius: 5px;
    text-align: center;
    padding: 6px;
    cursor: pointer;
    transition: all ease-in-out .3s;
  }
  .timer{
    color: rgb(7, 7, 7);
    font-size: 70px;
    margin-top: -210px;
  }
  .interval{
    color: rgb(255, 255, 255);
    flex: 1;
    width: 420px;
    margin-top: 15px;
  }
  .interval ul{
    text-align: center;
  }
  .interval ul li{
    list-style: none;
    background-color: rgb(85, 85, 85);
    padding: 15px;
    margin-bottom: 10px;
  }

  

  </style>
<template>
  <div class="container hello">
    <h1>About us</h1>
    <p>
      Some text here.
    </p>
  </div>
</template>

<script>
export default {
  name: 'AboutUs',
  props: {}
}
</script>

<style>
div.hello {
  padding: 3rem 1.5rem;
  text-align: center;
}
</style>

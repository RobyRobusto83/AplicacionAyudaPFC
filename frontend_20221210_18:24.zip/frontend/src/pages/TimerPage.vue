<template>
    <div>
        <TimerClock/>
    </div>
</template>

<script>
import TimerClock from '@/components/TimerClock.vue';
export default {
    name: 'TimerPage',
    components: {
      TimerClock
    }
  }
</script>
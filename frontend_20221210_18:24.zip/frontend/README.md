# 

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

npm install vue-router@3

https://styde.net/instalacion-y-uso-de-vue-router-en-vue-js-2/
https://router.vuejs.org/guide/#javascript